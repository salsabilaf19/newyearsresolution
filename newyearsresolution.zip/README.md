# newyearsresolution
Basically, it’s your wish for the new “you”. Every year we always want to upgrade ourselves, so we should make a list to track, Are we succeed to completed the mission? Are you? Become the new “you”?
